AI TRADING ANALYSIS - ANDROID APK STARTER

Ye Android APK starter project hai. Is mein indicator-based Forex analysis hai; trained AI/ML model nahi.

Features:
- Android WebView app
- Twelve Data se Forex 1-minute candles
- EMA 9, EMA 21, RSI 14 aur MACD based UP/DOWN/WAIT estimate
- API key phone ke local storage mein rakhi jati hai
- Quotex OTC feed ko jaan boojh kar UNAVAILABLE dikhaya jata hai; fake prices/signals nahi banaye jate
- Koi automatic trade execution nahi

APK build karne ka tareeqa:
1. Is project ke tamam files GitHub repository ke root mein upload/merge karein.
2. GitHub mein Actions tab kholein.
3. Build Android APK workflow run karein (ya main branch par project files push karein).
4. Workflow complete hone par run kholein.
5. Artifacts mein AI-Trading-Analysis-debug-APK download karein.
6. ZIP extract karke app-debug.apk Android par install karein.

Security:
- API key GitHub mein, source code mein ya screenshot mein mat rakhein.
- App mein key manually enter hoti hai aur isi phone par localStorage mein save hoti hai. Client-side app mein API key ko fully secret nahi rakha ja sakta; phone/app compromise hone par key expose ho sakti hai. Personal use only; Twelve Data dashboard se quota monitor karein aur zarurat par key rotate karein.

Limitations:
- Twelve Data free plan ke quotas/coverage apply honge.
- Live feed internet aur provider availability par depend karta hai.
- Background 24/7 service guarantee nahi; Android battery optimization app ko pause kar sakti hai.
- Signals guaranteed predictions nahi, sirf simple indicator rules hain.
- OTC data unavailable.

AI Trading Analysis - Android APK Project

1) Is ZIP ko extract karein.
2) Extracted folder ke ANDAR ki tamam files/folders GitHub repository ke root par upload karein.
   ZIP file ko akela upload karne se build nahi hota.
3) GitHub par Actions tab kholen. Workflow "Build Android APK" run hoga.
4) Build successful ho to workflow run ke Artifacts section se app-debug download karein.
5) APK Android phone par install karein.

Features:
- Forex 1-minute analysis via Twelve Data API.
- API key app ke andar manually enter hoti hai; code mein hard-code nahi.
- Quotex OTC live feed official public API ke baghair available nahi; OTC par WAIT/UNAVAILABLE dikhaya jata hai.
- App sirf analysis signals deti hai, trades execute nahi karti.
- Signals guaranteed nahi hain. Trading mein loss ka risk hai.

Security:
API key ko GitHub par kabhi upload/commit na karein. App mein key enter karte waqt bhi yaad rahe
ke personal APK mein key device par rahegi. Is starter app mein key session ke liye memory mein rakhi jati hai.
